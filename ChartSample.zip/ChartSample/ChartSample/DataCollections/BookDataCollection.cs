﻿using ChartSample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Threading;

namespace ChartSample.DataCollections
{
    public class BookDataCollection : ObservableCollection<BookDataPoint>
    {
        Timer timer = new Timer();
        public BookDataCollection()
        {
            GetData();
            timer.Interval = 10000;
            timer.Elapsed += Timer_Elapsed;
            timer.Enabled = true;

        }

        void GetData()
        {
            this.Clear();
            var groups = DataService.MSRBData.GroupBy(x => x.MSRB_Book).ToList();
            List<BookDataPoint> datas = new List<BookDataPoint>();
            foreach (var item in groups)
            {
                string per = ((double)item.ToList().Count / (double)DataService.MSRBData.Count).ToString("0.00%");
                this.Add(new BookDataPoint() { Book = item.Key + "  (" + per + ")", Count = item.ToList().Count });
            }
        }
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DataService.GenerateRandomData();
           

            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                GetData();
            }));
        }
    }
}
