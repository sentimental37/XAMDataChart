﻿using ChartSample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample.DataCollections
{
    public class OwnerTypeDataCollection : ObservableCollection<OwnerDataPoint>
    {
        public OwnerTypeDataCollection()
        {
            var groups = DataService.MSRBData.GroupBy(x => x.MSRB_IsWfOwned).ToList();
            int wfCount = 0;
            foreach (var item in groups)
            {
                if (item.Key == "Y")
                    this.Add(new OwnerDataPoint() { OwnedBy = "Wells Fargo", Count = item.ToList().Count });
                else
                    this.Add(new OwnerDataPoint() { OwnedBy = "Others", Count = item.ToList().Count });
            }
        }
    }
}
