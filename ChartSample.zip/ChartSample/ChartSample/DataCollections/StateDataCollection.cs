﻿using ChartSample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample.DataCollections
{
    public class StateDataCollection : ObservableCollection<StateDataPoint>
    {
        public StateDataCollection()
        {
            var groups = DataService.MSRBData.GroupBy(x => x.Security_State).ToList();
            foreach (var item in groups)
            {
                this.Add(new StateDataPoint() { StateName = item.Key, Count = item.ToList().Count });
            }
        }
    }
}
