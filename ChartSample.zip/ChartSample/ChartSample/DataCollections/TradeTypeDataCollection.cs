﻿using ChartSample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample.DataCollections
{
    public class TradeTypeDataCollection : ObservableCollection<TradeTypeDataPoint>
    {
        public TradeTypeDataCollection()
        {
            var groups = DataService.MSRBData.GroupBy(x => x.MSRB_TradeTypeInd).ToList();
            foreach (var item in groups)
            {
                this.Add(new TradeTypeDataPoint() { TradeType = item.Key, Count = item.ToList().Count });
            }
        }
    }
}
