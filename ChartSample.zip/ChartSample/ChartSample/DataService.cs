﻿using ChartSample.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample
{
    public static class DataService
    {
        private static ObservableCollection<EntityDataModel> msrbData;

        public static ObservableCollection<EntityDataModel> MSRBData
        {
            get
            {
                if (msrbData == null)
                {
                    msrbData = new ObservableCollection<EntityDataModel>();
                    GenerateDummy();
                }
                return msrbData;
            }
            set { msrbData = value; }
        }
        private static void GenerateDummy()
        {
            if (MSRBData != null)
            {
                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1710",
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "TSY",
                    Security_State = "NC"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1710",
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "SPD",
                    Security_State = "GA"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "J140",
                    MSRB_InventoryId = 3652,
                    MSRB_IsWfOwned = "N",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "TSY",
                    Security_State = "NC"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1710",
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "N",
                    MSRB_LargeTrade = "N",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "MMD",
                    Security_State = "GA"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1740",
                    MSRB_InventoryId = 1567,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "TSY",
                    Security_State = "NC"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1740",
                    MSRB_InventoryId = 1567,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "PS",
                    Security_State = "GA"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1740",
                    MSRB_InventoryId = 1567,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "SPD",
                    Security_State = "GA"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "J140",
                    MSRB_InventoryId = 3652,
                    MSRB_IsWfOwned = "N",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "TSY",
                    Security_State = "NC"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "J140",
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "N",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "SPD",
                    Security_State = "GC"
                });

                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = "1710",
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "MMD",
                    Security_State = "SC"
                });
            }
        }

        static List<string> books = new List<string>() {"J020","NO21","NO10" };
        public static void GenerateRandomData()
        {
            if (MSRBData != null)
            {
                MSRBData.Add(new EntityDataModel
                {
                    MSRB_Book = books[new Random().Next(0,2)],
                    MSRB_InventoryId = 1063,
                    MSRB_IsWfOwned = "Y",
                    MSRB_LargeTrade = "Y",
                    MSRB_MessageId = Guid.NewGuid().ToString(),
                    MSRB_SecurityId = "ABCD1234",
                    MSRB_TradeTypeInd = "TSY",
                    Security_State = "NC"
                });
                
            }
        }
    }
}
