﻿using ChartSample.DataCollections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample
{
    public class MainWindowViewModel : ObservableModel
    {
        public MainWindowViewModel()
        {
            tradeData = new TradeTypeDataCollection();
            ownerData = new OwnerTypeDataCollection();
            stateData = new StateDataCollection();
            bookData = new BookDataCollection();
        }
        private TradeTypeDataCollection tradeData;

        public TradeTypeDataCollection TradeData
        {
            get { return tradeData; }
            set { tradeData = value; }
        }


        private OwnerTypeDataCollection ownerData;

        public OwnerTypeDataCollection OwnerData
        {
            get { return ownerData; }
            set { ownerData = value; }
        }

        private StateDataCollection stateData;

        public StateDataCollection StateData
        {
            get { return stateData; }
            set { stateData = value; }
        }

        private BookDataCollection bookData;

        public BookDataCollection BookData
        {
            get { return bookData; }
            set { bookData = value; }
        }

    }
}
