﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample.Model
{
    public class EntityDataModel
    {
        private string _MSRB_TradeTypeInd;

        public string MSRB_TradeTypeInd
        {
            get { return _MSRB_TradeTypeInd; }
            set { _MSRB_TradeTypeInd = value; }
        }

        private string _Security_State;

        public string Security_State
        {
            get { return _Security_State; }
            set { _Security_State = value; }
        }

        private string _MSRB_SecurityId;

        public string MSRB_SecurityId
        {
            get { return _MSRB_SecurityId; }
            set { _MSRB_SecurityId = value; }
        }

        private string _MSRB_LargeTrade;

        public string MSRB_LargeTrade
        {
            get { return _MSRB_LargeTrade; }
            set { _MSRB_LargeTrade = value; }
        }

        private string _MSRB_IsWfOwned;

        public string MSRB_IsWfOwned
        {
            get { return _MSRB_IsWfOwned; }
            set { _MSRB_IsWfOwned = value; }
        }

        private string _MSRB_MessageId;

        public string MSRB_MessageId
        {
            get { return _MSRB_MessageId; }
            set { _MSRB_MessageId = value; }
        }

        private long _MSRB_InventoryId;

        public long MSRB_InventoryId
        {
            get { return _MSRB_InventoryId; }
            set { _MSRB_InventoryId = value; }
        }

        private string _MSRB_Book;

        public string MSRB_Book
        {
            get { return _MSRB_Book; }
            set { _MSRB_Book = value; }
        }
    }
}
