﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChartSample.data
{
    public class PieDataCollection
    {
        private ObservableCollection<PieDataModel> dataList;

        public ObservableCollection<PieDataModel> DataList
        {
            get { return dataList; }
            set { dataList = value; }
        }

        public PieDataCollection()
        {
            DataList = new ObservableCollection<PieDataModel>();
            DataList.Add(new PieDataModel() { TradeType = "TSY", TotalCount = 30 });
            DataList.Add(new PieDataModel() { TradeType = "SPD", TotalCount = 70 });
            DataList.Add(new PieDataModel() { TradeType = "MAT", TotalCount = 10 });
            DataList.Add(new PieDataModel() { TradeType = "PX", TotalCount = 40 });
        }
    }
    public class PieDataModel
    {
        public string TradeType { get; set; }
        public int TotalCount { get; set; }
    }

}
