﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Data
{
    public class DataModelCollection : ObservableCollection<DataModel>
    {
        public DataModelCollection()
        {
            this.Add(new DataModel { Spending = 20, Budget = 60, Label = "Administration" });
            this.Add(new DataModel { Spending = 80, Budget = 40, Label = "Sales" });
            this.Add(new DataModel { Spending = 30, Budget = 60, Label = "IT"});
            this.Add(new DataModel { Spending = 80, Budget = 40, Label = "Marketing" });
            this.Add(new DataModel { Spending = 40, Budget = 60, Label = "Development"});
            this.Add(new DataModel { Spending = 60, Budget = 20, Label = "CustomerSupport" });
        }

    }
    public class DataModel
    {
        public string Label { get; set; }
        public string LabelPercent 
        { 
            get 
            {
                return (Label + ((Spending / Budget) * 100)) + "%";
            }  
        }
        public double Spending { get; set; }
        public double Budget { get; set; }

        public string ToolTip { get { return String.Format("{0}, {1} {2}, {3} {4}", Label, "Spending", Spending, "Budget", Budget); } }

    }
}
