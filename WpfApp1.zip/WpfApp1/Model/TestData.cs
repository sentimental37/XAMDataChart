﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Data;

namespace WpfApp1.Model
{
    public class LabelWithPercentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //double dv = (double)value;
            //if (dv > 0)
            //    return dv / 100;

            return value + "%";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class PercentValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double dv = (double)value;
            if (dv > 0)
                return dv / 100;

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class TestData : ObservableCollection<TestDataItem>
    {
        public TestData()
        {
            Add(new TestDataItem { Label = "IBM", Value = 7 });
            Add(new TestDataItem { Label = "SONY", Value = 5 });
            Add(new TestDataItem { Label = "DELL", Value = 3 });
            Add(new TestDataItem { Label = "Apple", Value = 4 });
            Add(new TestDataItem { Label = "Hitachi", Value = 1 });
            Add(new TestDataItem { Label = "Acer", Value = 1 });
            Add(new TestDataItem { Label = "HP", Value = 2 });
            Add(new TestDataItem { Label = "Asus", Value = 2 });
            Add(new TestDataItem { Label = "Gateway", Value = 1 });
        }
    }

    public class TestDataItem
    {
        public string Label { get; set; }
        public double Value { get; set; }
    }
}
